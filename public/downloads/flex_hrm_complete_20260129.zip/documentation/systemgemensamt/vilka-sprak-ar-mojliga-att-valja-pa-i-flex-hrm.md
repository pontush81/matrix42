# Vilka språk är möjliga att välja på i Flex HRM?

**Datum:** den 7 november 2025  
**Kategori:** Systemgemensamt  
**Underkategori:** Användare & Behörighet  
**Typ:** other  
**Svårighetsgrad:** beginner  
**Tags:** användare  
**Bilder:** 0  
**URL:** https://knowledge.flexhrm.com/sv/mojliga-sprak-flex-hrm-0

---

Med funktionen för språk har ni möjlighet att ge användaren möjlighet att själv välja språk. Då ser användaren Flex HRM utifrån valt språk.
Möjliga val av språk
Svenska
N
orsk bokmål
Dansk
English
Suomi
Obs!
Kräver tilläggsmodulen Språk i din programversion.
Företagets huvudspråk sätts på företaget vid uppstart.  Se
Allmänt > Företag.
När en användare loggar in är företagets huvudspråk förvalt, men det är möjligt för användaren att själv byta språk.
