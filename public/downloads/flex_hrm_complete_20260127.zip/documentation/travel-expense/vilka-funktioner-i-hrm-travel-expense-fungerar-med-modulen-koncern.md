# Vilka funktioner i HRM Travel & Expense fungerar med modulen Koncern?

**Datum:** den 3 december 2025  
**Kategori:** Travel & Expense  
**Underkategori:** Attestering  
**Typ:** feature  
**Svårighetsgrad:** advanced  
**Tags:** attestering  
**Bilder:** 0  
**URL:** https://knowledge.flexhrm.com/sv/vilka-funktioner-i-hrm-travel-fungerar-med-modulen-koncern

---

En kort sammanfattning av vilka rapporter och andra funktioner som fungerar med modulen "Koncernhantering" i HRM Travel & Expense
Vad ingår i koncernhanteringen?
Startsida
: Påminnelser
Granskning
: Attesteringvyn
Rapportgenerator
: Datakälla Fordon
Anställdaregistret:
Anställningsdatum inom koncern - syns på den aktuella anställningen.
Möjlighet att hämta ledigt anställningsnr inom koncern (samt en anställd kan ha samma anställningsnr i två bolag så länge den även har samma personnr)
