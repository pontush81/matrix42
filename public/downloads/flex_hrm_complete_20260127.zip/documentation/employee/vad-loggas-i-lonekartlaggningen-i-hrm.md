# Vad loggas i Lönekartläggningen i HRM?

**Datum:** den 4 november 2025  
**Kategori:** Employee  
**Underkategori:** Anställningshantering  
**Typ:** other  
**Svårighetsgrad:** beginner  
**Tags:** anställning  
**Bilder:** 0  
**URL:** https://knowledge.flexhrm.com/sv/vad-loggas-i-hrm-lonekartlagging-0

---

Följande loggas i lönekartläggningen
Lönekartläggning skapad
Lönekartläggning beräknas
Anställning borttagen/tillagd
Klarmarkering/Klarmarkering borttagen
Byte av arbete i Förberedelser
Inställning befintligt arbete ändrat
